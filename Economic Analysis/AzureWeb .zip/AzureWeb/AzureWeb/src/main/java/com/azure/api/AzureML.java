package com.azure.api;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Iterator;
import java.util.zip.InflaterInputStream;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class AzureML {

    public static String apiurl;
    public static String apikey;
    public static String cluster = "";
    // Calling Time Series GDP USA
    public String[] callTimeSeriesGdpUs(String json) {
        System.out.println("calling time series for GDP USA: ");

        apiurl ="https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/ddc00a8f20524469b29400f4d9039dad/execute?api-version=2.0&details=true";
        apikey = "mzTH81e3GawvFZwSNefeoO08P/vjhi0ciQid9b3ENpCjkLRDgcjhv/QJklgpp138iV4f4StAcaYv0ocmXNb61Q==";

        String result = rrsHttpPost(json);
        return retrieveOutput(result);
    }
     public String[] callTimeSeriesGdpIn(String json) {
        System.out.println("calling time series for GDP USA: ");

        apiurl ="https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/8b132fcbb29a41d587f39cb44db16ed5/execute?api-version=2.0&details=true";
        apikey = "w6QHQ/t4fhrDa4mGZGn53ppQpPQRaM74jw77XdIKQHGaTAp0aD65e3pEE7vFQNXEuwdJ4XfdvLVTogbkwx+tuQ==";

        String result = rrsHttpPost(json);
        return retrieveOutput(result);
    }
    // Calling Time Series Population USA
    public String[] callTimeSeriesPopulationUs(String json) {
        System.out.println("calling time series for Population USA: ");

        apiurl ="https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/4fb5961b17f740d0bd46526437b8a20d/execute?api-version=2.0&details=true";
        apikey = "5jFwc07v3EmPzCu6A/iD8SJeIQPntuK0oqIWFio+QAMWSGEe/py8EDsAIZViLQhc8ZpZqdbwJMIjXrnmYMB/dg==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }
     public String[] callTimeSeriesPopulationIn(String json) {
        System.out.println("calling time series for Population USA: ");

        apiurl ="https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/2ec24500b0254afca8b37e0ac61ef3b7/execute?api-version=2.0&details=true";
        apikey = "iNhx1r9sfBorVh4Y1wCnJoMlln9xrC7mRV3i+fez97TxziQ8SXpAxpTJV3gCTpZGBie6SvS/5RvhBWphit5MVg==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }

    // Calling Time Series Import USA
    public String[] callTimeSeriesImportUs(String json) {
        System.out.println("calling time series for Import USA: ");

        apiurl ="https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/53b5095d3bf14f759f189fa2440bae39/execute?api-version=2.0&details=true";
        apikey = "GTdWEY7C6PFXTh7Da9PCqPagt0hdR82lhlopGKcDLg4Uw5tc63BbZ5fT8hDCW4QX+IJK8qW5+xv25sGQZlUNXQ==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }
    
     public String[] callTimeSeriesImportIn(String json) {
        System.out.println("calling time series for Import USA: ");

        apiurl ="https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/9fd5889859a54817871b097e1bd935ef/execute?api-version=2.0&details=true";
        apikey = "dhUjVa3VCciDBJDoxfrU7hUYPMqZpIEJaTa993CFo7C6X3fECew44TAeNcrDO0A+Wib4+ucLpOmDIRuZc9pn2A==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }
     public String[] callTimeSeriesCpiIn(String json) {
        System.out.println("calling time series for Import USA: ");

        apiurl ="https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/1609292718074de69fba0deded12ae7a/execute?api-version=2.0&details=true";
        apikey = "a84mUiFfUhrY/8J1r0TeYl64F/ML8MrVahCcuIzuPJ6CwEUrL51Sate01EFr09FglRLvepqexirpn67d6VpUTQ==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }
     
      public String[] callTimeSeriesWpiIn(String json) {
        System.out.println("calling time series for Import USA: ");

        apiurl ="https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/6f4454c7c55344daaaf7e5f1c5930a18/execute?api-version=2.0&details=true";
        apikey = "Tn3eSZiu1MAVAiUYSSrWU6FAslyzKX8qUMvjrvYoSKslmkYyZ0UqJIzCls4/JKYAlpsbx3QC/ahTIJ/bkl1QAg==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }
    
    
    // Calling Time Series Import USA
    public String[] callTimeSeriesExportUs(String json) {
        System.out.println("calling time series for Import USA: ");

        apiurl ="https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/57401670b5fa4c4dbca10a1504470a8e/execute?api-version=2.0&details=true";
        apikey = "t4nti4TDnSFPx+s6KO/1khiKA0BE1GRY/jYPaXhIz7ZbLKySyxuNxdLbWDafl7VHXV4WeybP6J4T47JZJwt6Zw==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }

    // Calling Logistic Regression model 
    public String[] callTimeSeriesInflationUs(String json) {
        System.out.println("calling decision jungle model: ");

        apiurl = "https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/499319dce51348a1ae0151954d9b2f8c/execute?api-version=2.0&details=true";
        apikey = "D54V2TbNjMwDUkZORhajSuB4rfpeNPJovYjMQbUoGTygjxkm6zc3rQQSX10wiMnD7Sw1UHAjYmyXI1zaG06Oiw==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }
    
     public String[] callTimeSeriesInflationIn(String json) {
        System.out.println("calling decision jungle model: ");

        apiurl = "https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/d42d8404129642f78b169f5bdebee344/execute?api-version=2.0&details=true";
        apikey = "WVpf0iMuipIY1hR8BhX83LMZWm6GbBC0Nei4ShhNngE4yDtG7rC2rPskUeJl3y+hqA66eyabiFMzuSokWfIm1Q==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }

    public String[] callTimeSeriesPPIUs(String json) {
        System.out.println("calling decision jungle model: ");

        apiurl = "https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/578518bb20164c4fac63cd2f417d7bd8/execute?api-version=2.0&details=true";
        apikey = "JKnAXGMayeVunvG9/Rhfw0EcFakuY3ZbDMzbWKrSXGJcgVQJDrM7UgO7WpxvhvCTLJiZLgfcZ9rBmm6SiBF0DQ==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }
   
    public String[] callTimeSeriesIndustrialUs(String json) {
        System.out.println("calling time series: ");

        apiurl = "https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/2f8628629f874a609992eb9326e8defa/execute?api-version=2.0&details=true";
        apikey = "4lTcH6qc297DPhRiJJn7hkJX4L5e5JB/pS9Baeb4F7SawYNzGlKwGUZFEo0EN/vSmF7pFIECPbnzIQr9ORLTpQ==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }
    
    public String[] callTimeSeriesIndustrialIn(String json) {
        System.out.println("calling time series: ");

        apiurl = "https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/a50a6e0706f44deb8c4cab30bb73d2e6/execute?api-version=2.0&details=true";
        apikey = "YocxlHUPQluVxF/XK8MbCg0/w602gRFLWI0wLkaYo/6VHL3tNiixl0jclKctJmRDzrFxNQE0MugFVdezEuKBwg==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }

    public String[] callTimeSeriesPersonalIncomeUs(String json) {
        System.out.println("calling random forest for prediction: ");

        apiurl = "https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/508f95c31c6641f78d23a6cd2a199d41/execute?api-version=2.0&details=true";
        apikey = "QQm/5aU11mdtULlhtFxsysIQ1vCfRljkLI5cSHEgOjdY6KtWjs0jfXx5sDYCj+ZLfQth/sv8Xp5yGelAKiTPhQ==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }

    public String[] callTimeSeriesCpiUs(String json) {
        System.out.println("calling random forest for prediction: ");

        apiurl = "https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/1a6c6828627942d58ffa86515e27108a/execute?api-version=2.0&details=true";
        apikey = "471JJZ5xkpqY3IKNeQ7W/Il4Bq/oRa8OY4/IzZUlnwkEgwtLrkOc6HOgHV9xZ4LOAIOPm8WzwAcnFGcmZuSU3Q==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }
    
     public String[] callTimeSeriesUnemploymentRate(String json) {
        apiurl = "https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/461dc1397f5b4470b2a45b327d2558e4/execute?api-version=2.0&details=true";
        apikey = "gldCh25PQsRzQRbZ4tIlTsmmjDitzkFVyiPHSzgf3+tzhxMDAlyLUYfJ8bpzREU2IabAMOOnBwaGgpMvpDSZ3g==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }
     
     public String[] callTimeSeriesUnemploymentRateIn(String json) {
        apiurl = "https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/fbadeb8633a84e55885bbd1ad989d6c9/execute?api-version=2.0&details=true";
        apikey = "uQE1Mw00/1R38M6crGjqnVaCgc4/fQnI/xmCK6fp8/c+xD2VsX8IajSXMkn7H6KLFBEJtwFhT6WI1AXmjwyXUA==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }
     
     public String[] callTimeSeriesM2Us(String json) {
        apiurl = "https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/fae705616038444a9d1ef5ed1c309713/execute?api-version=2.0&details=true";
        apikey = "Z7pUaUsMBvNpnQz+m3vTxlyLOU3wBt+3O/KmzMXsMqJJExrsb38ULXad3psbQI9Joyfg07s+EXNDcRr/rXawcg==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }
     
      public String[] callTimeSeriesExchangeIn(String json) {
        apiurl = "https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/0e8d40bd3b1c44f492d333f7b6cba234/execute?api-version=2.0&details=true";
        apikey = "VLMsMwTfuylDmMNxuo/9RelnlWrcGYMlFauTihuAkLQbe0PCDCl/6m9OrCmwiNib4B7oywxfrSioNXPZvKGVkg==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }
      
     public String[] callTimeSeriesM3In(String json) {
        apiurl = "https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/cf649ef5269f4bc79773add3a910daa6/execute?api-version=2.0&details=true";
        apikey = "HdFmrflfn/UL5cdC1YLjp8sWE8ofba2VtyJzZ2PQmXh7/UvjYNtME+IoUDtqcj8JAWFHXI6D1j9xLNt09mG70Q==";

        String input = rrsHttpPost(json);
        return retrieveOutput(input);
    }
     public String callRandomForestUs(String json) {
        apiurl = "https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/a61133acca494b418252e94be8ebfb7c/execute?api-version=2.0&details=true";
        apikey = "hj2OTIEH8eABLKZ+8qZ7F4YHqr/INf0uKVjAslYU8qVx1EPuXSy+UF9m8SUONj1JZueUQ7SAQA2uknr/Q3CqXg==";

        String input = rrsHttpPost(json);
        return retrieverecessionOutput(input);
    }
     
     public String callRandomForestIn(String json) {
        apiurl = "https://ussouthcentral.services.azureml.net/workspaces/b5e1e26571ff4ecc9e145bbebf3a9d97/services/bc82e45dc29e4bbba6b2d87ee87d67a8/execute?api-version=2.0&details=true";
        apikey = "7kx+H3CsZWGQrsj+HZGtsM1KzXu3eRUgOtZ5x6f03pvyzQqDJhHZpwpux8YUzMBKEe43bNdU4Q3vtYhyNXC7iQ==";

        String input = rrsHttpPost(json);
        return retrieverecessionOutput(input);
    }
    /**
     * Call REST API for retrieving prediction from Azure ML
     *
     * @return response from the REST API
     */
    public String rrsHttpPost(String jsonBody) {

        HttpPost post;
        HttpClient client;
        StringEntity entity;

        try {

            // create HttpPost and HttpClient object
            post = new HttpPost(apiurl);
            client = HttpClientBuilder.create().build();

            // setup output message by copying JSON body into 
            // apache StringEntity object along with content type
            entity = new StringEntity(jsonBody, HTTP.UTF_8);
            entity.setContentEncoding(HTTP.UTF_8);
            entity.setContentType("text/json");

            // add HTTP headers
            post.setHeader("Accept", "text/json");
            post.setHeader("Accept-Charset", "UTF-8");

            // set Authorization header based on the API key
            post.setHeader("Authorization", ("Bearer " + apikey));
            post.setEntity(entity);

            // Call REST API and retrieve response content
            HttpResponse authResponse = client.execute(post);

            return EntityUtils.toString(authResponse.getEntity());

        } catch (Exception e) {
            System.out.println("Error occurred while calling the service!!");
            return e.toString();
        }
    }

    public String[] retrieveOutput(String input) {
        try {
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(input);

            JSONObject json = (JSONObject) obj;

            JSONObject result = (JSONObject) json.get("Results");
            System.out.println(json.get("Results"));

            JSONObject output1 = (JSONObject) result.get("output1");
            System.out.println(result.get("output1"));

            JSONObject value = (JSONObject) output1.get("value");
            System.out.println(output1.get("value"));

            String[] res = new String[40];
            JSONArray strArray = (JSONArray) value.get("Values");
            Iterator<Object> itr = strArray.iterator();
            int i =0;
            while (itr.hasNext()) {
                res[i] = itr.next().toString();
                 i++;
            }
            return res;
        } catch (Exception e) {
            System.out.println("Error while parsing output!!");
            e.printStackTrace();;
        }

        return null;
    }
    
    public String retrieverecessionOutput(String input)
    {
        try {
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(input);

            JSONObject json = (JSONObject) obj;

            JSONObject result = (JSONObject) json.get("Results");
            System.out.println(json.get("Results"));

            JSONObject output1 = (JSONObject) result.get("output1");
            System.out.println(result.get("output1"));

            JSONObject value = (JSONObject) output1.get("value");
            System.out.println(output1.get("value"));

            String res = null;
            JSONArray strArray = (JSONArray) value.get("Values");
            Iterator<Object> itr = strArray.iterator();

            while (itr.hasNext()) {
                res = itr.next().toString();
                break;
            }

            StringBuilder sb = new StringBuilder();
            sb.append(res);

            String s = res.substring(2, sb.indexOf("]"));

            String output = s.substring(0, s.lastIndexOf('"'));

            System.out.println(output);
            return output;
        } catch (Exception e) {
            System.out.println("Error while parsing output!!");
            e.printStackTrace();;
        }

        return null;
    }
    
}