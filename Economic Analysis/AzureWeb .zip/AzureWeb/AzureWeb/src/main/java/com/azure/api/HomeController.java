package com.azure.api;

import static java.lang.Math.ceil;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

    final static String apikey = "GeG32HHijMlWdeIa/JcaV7QKFbpoezpaNXHib3+mEep+1xAcyO1vlwSC9GOatsmxfyrt+prrA55+1vbjkyah9g==";
    final static String apiurl = "https://ussouthcentral.services.azureml.net/workspaces/253767f4788549c1baaad7723c456e77/services/27e620cbde5548348d16c1ae1653e560/execute?api-version=2.0&details=true";
    public static String jsonBody;

    private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

    /**
     * Simply selects the home view to render by returning its name.
     */
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String homeredirect(Locale locale, Model model) {
        return "index";
    } 
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String home(Locale locale, Model model) {
        return "index";
    }
    @RequestMapping(value = "/morris", method = RequestMethod.GET)
    public String morris(Locale locale, Model model) {
        return "morris";
    }

    @RequestMapping(value = "/service1", method = RequestMethod.POST)
    public ModelAndView service1(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("morris");
        String quarter = request.getParameter("quarter");
        int year = Integer.parseInt(request.getParameter("year"));
        String country = "USA";
        String jsonBody = null;
        String jsonBodyPop = null;
        String jsonBodycpi=null;
        String jsonBodywpi=null;
        String jsonBodyimport = null;
        String jsonBodym3 = null;
        String jsonBodyunemp = null;
        String jsonBodyinflation = null;
        String jsonBodyindus=null;
        String jsonBodyexchange=null;
        String jsonBodyrecessionin=null;
        int gdp =0;
            for(int i=0;i<11;i++)
            {
            JSONArray allValues = new JSONArray();
            JSONArray value = new JSONArray();
            JSONObject obj = new JSONObject();
            JSONObject inputs = new JSONObject();
            JSONObject input = new JSONObject();
            JSONArray columnName = new JSONArray();    
            columnName.add("quarter");
            columnName.add("Year");
            if(i==0)
            {
            columnName.add("GDP");
            }else if(i==1)
            {
            columnName.add("Population");
            }else if(i==2){
                columnName.add("CPI");  }  
            else if(i==3){
                columnName.add("WPI");
            }   
            else if(i==4){
                columnName.add("Import");
            }else if(i==5){
                columnName.add("M3");}
            else if(i==6){
                columnName.add("Unemployment");
            }
            else if(i==7){columnName.add("Inflation_Rate");}
            else if(i==8){columnName.add("Industrial_Production");}
            else if(i==9){columnName.add("Exchange_Rate");}
            else if(i==10){columnName.add("Recession");}
            value.add(quarter);
            value.add(year);
            value.add(0);
            allValues.add(value);
            input.put("ColumnNames", columnName);
            input.put("Values", allValues);
            inputs.put("input1", input);
            obj.put("Inputs", inputs);
            if(i ==0)
            {jsonBody = obj.toString();}
            else if(i == 1)
            {
            jsonBodyPop = obj.toString();
            }
            else if(i==2){jsonBodycpi=obj.toString();}
            else if(i==3){jsonBodywpi=obj.toString();}
            else if(i==4){jsonBodyimport=obj.toJSONString();}
            else if(i==5){jsonBodym3=obj.toJSONString();}
            else if(i==6){jsonBodyunemp=obj.toJSONString();}
            else if(i==7){jsonBodyinflation=obj.toJSONString();}
            else if(i==8){jsonBodyindus=obj.toJSONString();}
            else if(i==9){jsonBodyexchange=obj.toJSONString();}
            else if(i==10){jsonBodyrecessionin=obj.toJSONString();}
            }
             AzureML am = new AzureML();

        String gdp_in[] = new String[40];
        String population_in[] = new String[40];
        String cpi_in[] = new String[40];
        String wpi_in[] = new String[40];
        String import_in[]=new String[40];
        String m3_in[]=new String[40];
        String unemp_in[]=new String[40];
        String inflation_in[] = new String[40];
        String indus_in[] = new String[40];
        String exchange_in[] = new String[40];
        String recession_in=null;
        gdp_in = am. callTimeSeriesGdpIn(jsonBody);
        population_in = am.callTimeSeriesPopulationIn(jsonBodyPop);
        cpi_in=am.callTimeSeriesCpiIn(jsonBodycpi);
        wpi_in=am.callTimeSeriesWpiIn(jsonBodywpi);
        import_in=am.callTimeSeriesImportIn(jsonBodyimport);
        m3_in=am.callTimeSeriesM3In(jsonBodym3);
        unemp_in=am.callTimeSeriesUnemploymentRateIn(jsonBodyunemp);
        inflation_in=am.callTimeSeriesInflationIn(jsonBodyinflation);
        indus_in=am.callTimeSeriesIndustrialIn(jsonBodyindus);
        exchange_in=am.callTimeSeriesExchangeIn(jsonBodyexchange);
         if (gdp_in != null && population_in!=null && import_in!=null) {
            String[] tokens_gdp = new String[40];
            String[] tokens_population = new String[40];
            String[] tokens_cpi=new String[40];
            String[] tokens_wpi=new String[40];
            String[] tokens_import=new String[40];
            String[] tokens_m3=new String[40];
            String[] tokens_unemp=new String[40];
            String[] tokens_inflation=new String[40];
            String[] tokens_indus=new String[40];
            String[] tokens_exchange=new String[40]; 
           for(int i =0 ;i<40;i++)
            {   
             String x = gdp_in[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_gdp[i] = x.replace("\"", "");
             x = population_in[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_population[i] = String.valueOf(ceil(Double.parseDouble(x.replace("\"", ""))));
             x = cpi_in[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_cpi[i] = x.replace("\"", "");
             x = wpi_in[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_wpi[i] = x.replace("\"", "");
             x = import_in[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_import[i] = x.replace("\"", "");
             x = m3_in[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_m3[i] = x.replace("\"", "");
             x = unemp_in[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_unemp[i] = x.replace("\"", "");
             x = inflation_in[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_inflation[i] = x.replace("\"", "");
             x = indus_in[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_indus[i] = x.replace("\"", "");
             x = exchange_in[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_exchange[i] = x.replace("\"", "");
            }
            String[] desc = new String[20];
            String[] output = new String[20];
            switch(year)
            {
                case 2015:
                {
                   if(quarter.equals("Q1"))
                   {
                       output[0]=tokens_gdp[0];
                       output[1]=tokens_population[0];
                       output[2]= tokens_cpi[0];
                       output[3]=tokens_wpi[0];
                       output[4]=tokens_import[0];
                       output[5]=tokens_m3[0];
                       output[6]= tokens_unemp[0];
                       output[7]=tokens_inflation[0];
                       output[8] = tokens_indus[0];
                       output[9] = tokens_exchange[0];
                       
                   }else if(quarter.equals("Q2"))
                   {
                     output[0]=tokens_gdp[1];
                       output[1]=tokens_population[1];
                       output[2]= tokens_cpi[1];
                       output[3]=tokens_wpi[1];
                       output[4]=tokens_import[1];
                       output[5]=tokens_m3[1];
                       output[6]= tokens_unemp[1];
                       output[7]=tokens_inflation[1];
                       output[8] = tokens_indus[1];
                       output[9] = tokens_exchange[1];
                   }else if(quarter.equals("Q3"))
                   {
                      output[0]=tokens_gdp[2];
                       output[1]=tokens_population[2];
                       output[2]= tokens_cpi[2];
                       output[3]=tokens_wpi[2];
                       output[4]=tokens_import[2];
                       output[5]=tokens_m3[2];
                       output[6]= tokens_unemp[2];
                       output[7]=tokens_inflation[2];
                       output[8] = tokens_indus[2];
                       output[9] = tokens_exchange[2];
                   }else
                   {
                      output[0]=tokens_gdp[3];
                       output[1]=tokens_population[3];
                       output[2]= tokens_cpi[3];
                       output[3]=tokens_wpi[3];
                       output[4]=tokens_import[3];
                       output[5]=tokens_m3[3];
                       output[6]= tokens_unemp[3];
                       output[7]=tokens_inflation[3];
                       output[8] = tokens_indus[3];
                       output[9] = tokens_exchange[3];
                   }
                   break;
                }
                case 2016:
                     {
                   if(quarter.equals("Q1"))
                   {
                       output[0]=tokens_gdp[4];
                       output[1]=tokens_population[4];
                       output[2]= tokens_cpi[4];
                       output[3]=tokens_wpi[4];
                       output[4]=tokens_import[4];
                       output[5]=tokens_m3[4];
                       output[6]= tokens_unemp[4];
                       output[7]=tokens_inflation[4];
                       output[8] = tokens_indus[4];
                       output[9] = tokens_exchange[4];
                   }else if(quarter.equals("Q2"))
                   {
                       output[0]=tokens_gdp[5];
                       output[1]=tokens_population[5];
                       output[2]= tokens_cpi[5];
                       output[3]=tokens_wpi[5];
                       output[4]=tokens_import[5];
                       output[5]=tokens_m3[5];
                       output[6]= tokens_unemp[5];
                       output[7]=tokens_inflation[5];
                       output[8] = tokens_indus[5];
                       output[9] = tokens_exchange[5];
                   }else if(quarter.equals("Q3"))
                   {
                        output[0]=tokens_gdp[6];
                       output[1]=tokens_population[6];
                       output[2]= tokens_cpi[6];
                       output[3]=tokens_wpi[6];
                       output[4]=tokens_import[6];
                       output[5]=tokens_m3[6];
                       output[6]= tokens_unemp[6];
                       output[7]=tokens_inflation[6];
                       output[8] = tokens_indus[6];
                       output[9] = tokens_exchange[6];
                   }else
                   {
                        output[0]=tokens_gdp[7];
                       output[1]=tokens_population[7];
                       output[2]= tokens_cpi[7];
                       output[3]=tokens_wpi[7];
                       output[4]=tokens_import[7];
                       output[5]=tokens_m3[7];
                       output[6]= tokens_unemp[7];
                       output[7]=tokens_inflation[7];
                       output[8] = tokens_indus[7];
                       output[9] = tokens_exchange[7];
                   }
                   break;
                }
                case 2017:
                {
                 if(quarter.equals("Q1"))
                   {
                       output[0]=tokens_gdp[8];
                       output[1]=tokens_population[8];
                       output[2]= tokens_cpi[8];
                       output[3]=tokens_wpi[8];
                       output[4]=tokens_import[8];
                       output[5]=tokens_m3[8];
                       output[6]= tokens_unemp[8];
                       output[7]=tokens_inflation[8];
                       output[8] = tokens_indus[8];
                       output[9] = tokens_exchange[8];
                   }else if(quarter.equals("Q2"))
                   {
                      output[0]=tokens_gdp[9];
                       output[1]=tokens_population[9];
                       output[2]= tokens_cpi[9];
                       output[3]=tokens_wpi[9];
                       output[4]=tokens_import[9];
                       output[5]=tokens_m3[9];
                       output[6]= tokens_unemp[9];
                       output[7]=tokens_inflation[9];
                       output[8] = tokens_indus[9];
                       output[9] = tokens_exchange[9];
                   }else if(quarter.equals("Q3"))
                   {
                       output[0]=tokens_gdp[10];
                       output[1]=tokens_population[10];
                       output[2]= tokens_cpi[10];
                       output[3]=tokens_wpi[10];
                       output[4]=tokens_import[10];
                       output[5]=tokens_m3[10];
                       output[6]= tokens_unemp[10];
                       output[7]=tokens_inflation[10];
                       output[8] = tokens_indus[10];
                       output[9] = tokens_exchange[10];
                       
                   }else
                   {
                       output[0]=tokens_gdp[11];
                       output[1]=tokens_population[11];
                       output[2]= tokens_cpi[11];
                       output[3]=tokens_wpi[11];
                       output[4]=tokens_import[11];
                       output[5]=tokens_m3[11];
                       output[6]= tokens_unemp[11];
                       output[7]=tokens_inflation[11];
                       output[8] = tokens_indus[11];
                       output[9] = tokens_exchange[11]; 
                   }
                   break;
                }
                case 2018:
                {
                 if(quarter.equals("Q1"))
                   {
                        output[0]=tokens_gdp[12];
                       output[1]=tokens_population[12];
                       output[2]= tokens_cpi[12];
                       output[3]=tokens_wpi[12];
                       output[4]=tokens_import[12];
                       output[5]=tokens_m3[12];
                       output[6]= tokens_unemp[12];
                       output[7]=tokens_inflation[12];
                       output[8] = tokens_indus[12];
                       output[9] = tokens_exchange[12];
                   }else if(quarter.equals("Q2"))
                   {
                       output[0]=tokens_gdp[13];
                       output[1]=tokens_population[13];
                       output[2]= tokens_cpi[13];
                       output[3]=tokens_wpi[13];
                       output[4]=tokens_import[13];
                       output[5]=tokens_m3[13];
                       output[6]= tokens_unemp[13];
                       output[7]=tokens_inflation[13];
                       output[8] = tokens_indus[13];
                       output[9] = tokens_exchange[13];
                   }else if(quarter.equals("Q3"))
                   {
                      output[0]=tokens_gdp[14];
                       output[1]=tokens_population[14];
                       output[2]= tokens_cpi[14];
                       output[3]=tokens_wpi[14];
                       output[4]=tokens_import[14];
                       output[5]=tokens_m3[14];
                       output[6]= tokens_unemp[14];
                       output[7]=tokens_inflation[14];
                       output[8] = tokens_indus[14];
                       output[9] = tokens_exchange[14];
                   }else
                   {
                        output[0]=tokens_gdp[15];
                       output[1]=tokens_population[15];
                       output[2]= tokens_cpi[15];
                       output[3]=tokens_wpi[15];
                       output[4]=tokens_import[15];
                       output[5]=tokens_m3[15];
                       output[6]= tokens_unemp[15];
                       output[7]=tokens_inflation[15];
                       output[8] = tokens_indus[15];
                       output[9] = tokens_exchange[15];
                   }
                   break;
                }
                case 2019:
                {
                 if(quarter.equals("Q1"))
                   {
                       output[0]=tokens_gdp[16];
                       output[1]=tokens_population[16];
                       output[2]= tokens_cpi[16];
                       output[3]=tokens_wpi[16];
                       output[4]=tokens_import[16];
                       output[5]=tokens_m3[16];
                       output[6]= tokens_unemp[16];
                       output[7]=tokens_inflation[16];
                       output[8] = tokens_indus[16];
                       output[9] = tokens_exchange[16];
                   }else if(quarter.equals("Q2"))
                   {
                       output[0]=tokens_gdp[17];
                       output[1]=tokens_population[17];
                       output[2]= tokens_cpi[17];
                       output[3]=tokens_wpi[17];
                       output[4]=tokens_import[17];
                       output[5]=tokens_m3[17];
                       output[6]= tokens_unemp[17];
                       output[7]=tokens_inflation[17];
                       output[8] = tokens_indus[17];
                       output[9] = tokens_exchange[17];
                   }else if(quarter.equals("Q3"))
                   {
                      output[0]=tokens_gdp[18];
                       output[1]=tokens_population[18];
                       output[2]= tokens_cpi[18];
                       output[3]=tokens_wpi[18];
                       output[4]=tokens_import[18];
                       output[5]=tokens_m3[18];
                       output[6]= tokens_unemp[18];
                       output[7]=tokens_inflation[18];
                       output[8] = tokens_indus[18];
                       output[9] = tokens_exchange[18];
                   }else
                   {
                      output[0]=tokens_gdp[19];
                       output[1]=tokens_population[19];
                       output[2]= tokens_cpi[19];
                       output[3]=tokens_wpi[19];
                       output[4]=tokens_import[19];
                       output[5]=tokens_m3[19];
                       output[6]= tokens_unemp[19];
                       output[7]=tokens_inflation[19];
                       output[8] = tokens_indus[19];
                       output[9] = tokens_exchange[19];
                   }
                   break;
                }
                 case 2020:
                {
                 if(quarter.equals("Q1"))
                   {
                        output[0]=tokens_gdp[20];
                       output[1]=tokens_population[20];
                       output[2]= tokens_cpi[20];
                       output[3]=tokens_wpi[20];
                       output[4]=tokens_import[20];
                       output[5]=tokens_m3[20];
                       output[6]= tokens_unemp[20];
                       output[7]=tokens_inflation[20];
                       output[8] = tokens_indus[20];
                       output[9] = tokens_exchange[20];
                   }else if(quarter.equals("Q2"))
                   {
                       output[0]=tokens_gdp[21];
                       output[1]=tokens_population[21];
                       output[2]= tokens_cpi[21];
                       output[3]=tokens_wpi[21];
                       output[4]=tokens_import[21];
                       output[5]=tokens_m3[21];
                       output[6]= tokens_unemp[21];
                       output[7]=tokens_inflation[21];
                       output[8] = tokens_indus[21];
                       output[9] = tokens_exchange[21];
                   }else if(quarter.equals("Q3"))
                   {
                      output[0]=tokens_gdp[22];
                       output[1]=tokens_population[22];
                       output[2]= tokens_cpi[22];
                       output[3]=tokens_wpi[22];
                       output[4]=tokens_import[22];
                       output[5]=tokens_m3[22];
                       output[6]= tokens_unemp[22];
                       output[7]=tokens_inflation[22];
                       output[8] = tokens_indus[22];
                       output[9] = tokens_exchange[22];
                   }else
                   {
                       output[0]=tokens_gdp[23];
                       output[1]=tokens_population[23];
                       output[2]= tokens_cpi[23];
                       output[3]=tokens_wpi[23];
                       output[4]=tokens_import[23];
                       output[5]=tokens_m3[23];
                       output[6]= tokens_unemp[23];
                       output[7]=tokens_inflation[23];
                       output[8] = tokens_indus[23];
                       output[9] = tokens_exchange[23];
                   }
                   break;
                }
                  case 2021:
                {
                 if(quarter.equals("Q1"))
                   {
                      output[0]=tokens_gdp[24];
                       output[1]=tokens_population[24];
                       output[2]= tokens_cpi[24];
                       output[3]=tokens_wpi[24];
                       output[4]=tokens_import[24];
                       output[5]=tokens_m3[24];
                       output[6]= tokens_unemp[24];
                       output[7]=tokens_inflation[24];
                       output[8] = tokens_indus[24];
                       output[9] = tokens_exchange[24]; 
                   }else if(quarter.equals("Q2"))
                   {
                        output[0]=tokens_gdp[25];
                       output[1]=tokens_population[25];
                       output[2]= tokens_cpi[25];
                       output[3]=tokens_wpi[25];
                       output[4]=tokens_import[25];
                       output[5]=tokens_m3[25];
                       output[6]= tokens_unemp[25];
                       output[7]=tokens_inflation[25];
                       output[8] = tokens_indus[25];
                       output[9] = tokens_exchange[25];
                   }else if(quarter.equals("Q3"))
                   {
                       output[0]=tokens_gdp[26];
                       output[1]=tokens_population[26];
                       output[2]= tokens_cpi[26];
                       output[3]=tokens_wpi[26];
                       output[4]=tokens_import[26];
                       output[5]=tokens_m3[26];
                       output[6]= tokens_unemp[26];
                       output[7]=tokens_inflation[26];
                       output[8] = tokens_indus[26];
                       output[9] = tokens_exchange[26];
                   }else
                   {
                        output[0]=tokens_gdp[27];
                       output[1]=tokens_population[27];
                       output[2]= tokens_cpi[27];
                       output[3]=tokens_wpi[27];
                       output[4]=tokens_import[27];
                       output[5]=tokens_m3[27];
                       output[6]= tokens_unemp[27];
                       output[7]=tokens_inflation[27];
                       output[8] = tokens_indus[27];
                       output[9] = tokens_exchange[27]; 
                   }
                   break;
                }
                 case 2022:
                {
                 if(quarter.equals("Q1"))
                   {
                        output[0]=tokens_gdp[28];
                       output[1]=tokens_population[28];
                       output[2]= tokens_cpi[28];
                       output[3]=tokens_wpi[28];
                       output[4]=tokens_import[28];
                       output[5]=tokens_m3[28];
                       output[6]= tokens_unemp[28];
                       output[7]=tokens_inflation[28];
                       output[8] = tokens_indus[28];
                       output[9] = tokens_exchange[28];
                   }else if(quarter.equals("Q2"))
                   {
                       output[0]=tokens_gdp[29];
                       output[1]=tokens_population[29];
                       output[2]= tokens_cpi[29];
                       output[3]=tokens_wpi[29];
                       output[4]=tokens_import[29];
                       output[5]=tokens_m3[29];
                       output[6]= tokens_unemp[29];
                       output[7]=tokens_inflation[29];
                       output[8] = tokens_indus[29];
                       output[9] = tokens_exchange[29];
                   }else if(quarter.equals("Q3"))
                   {
                      output[0]=tokens_gdp[30];
                       output[1]=tokens_population[30];
                       output[2]= tokens_cpi[30];
                       output[3]=tokens_wpi[30];
                       output[4]=tokens_import[30];
                       output[5]=tokens_m3[30];
                       output[6]= tokens_unemp[30];
                       output[7]=tokens_inflation[30];
                       output[8] = tokens_indus[30];
                       output[9] = tokens_exchange[30];
                   }else
                   {
                       output[0]=tokens_gdp[31];
                       output[1]=tokens_population[31];
                       output[2]= tokens_cpi[31];
                       output[3]=tokens_wpi[31];
                       output[4]=tokens_import[31];
                       output[5]=tokens_m3[31];
                       output[6]= tokens_unemp[31];
                       output[7]=tokens_inflation[31];
                       output[8] = tokens_indus[31];
                       output[9] = tokens_exchange[31];
                   }
                   break;
                }
                  case 2023:
                {
                 if(quarter.equals("Q1"))
                   {
                       output[0]=tokens_gdp[32];
                       output[1]=tokens_population[32];
                       output[2]= tokens_cpi[32];
                       output[3]=tokens_wpi[32];
                       output[4]=tokens_import[32];
                       output[5]=tokens_m3[32];
                       output[6]= tokens_unemp[32];
                       output[7]=tokens_inflation[32];
                       output[8] = tokens_indus[32];
                       output[9] = tokens_exchange[32];
                        
                   }else if(quarter.equals("Q2"))
                   {
                       output[0]=tokens_gdp[33];
                       output[1]=tokens_population[33];
                       output[2]= tokens_cpi[33];
                       output[3]=tokens_wpi[33];
                       output[4]=tokens_import[33];
                       output[5]=tokens_m3[33];
                       output[6]= tokens_unemp[33];
                       output[7]=tokens_inflation[33];
                       output[8] = tokens_indus[33];
                       output[9] = tokens_exchange[33];
                   }else if(quarter.equals("Q3"))
                   {
                       output[0]=tokens_gdp[34];
                       output[1]=tokens_population[34];
                       output[2]= tokens_cpi[34];
                       output[3]=tokens_wpi[34];
                       output[4]=tokens_import[34];
                       output[5]=tokens_m3[34];
                       output[6]= tokens_unemp[34];
                       output[7]=tokens_inflation[34];
                       output[8] = tokens_indus[34];
                       output[9] = tokens_exchange[34]; 
                   }else
                   {
                       output[0]=tokens_gdp[35];
                       output[1]=tokens_population[35];
                       output[2]= tokens_cpi[35];
                       output[3]=tokens_wpi[35];
                       output[4]=tokens_import[35];
                       output[5]=tokens_m3[35];
                       output[6]= tokens_unemp[35];
                       output[7]=tokens_inflation[35];
                       output[8] = tokens_indus[35];
                       output[9] = tokens_exchange[35];
                   }
                   break;
                }
                 case 2024:
                {
                 if(quarter.equals("Q1"))
                   {
                       output[0]=tokens_gdp[36];
                       output[1]=tokens_population[36];
                       output[2]= tokens_cpi[36];
                       output[3]=tokens_wpi[36];
                       output[4]=tokens_import[36];
                       output[5]=tokens_m3[36];
                       output[6]= tokens_unemp[36];
                       output[7]=tokens_inflation[36];
                       output[8] = tokens_indus[36];
                       output[9] = tokens_exchange[36];
                   }else if(quarter.equals("Q2"))
                       
                   {
                       output[0]=tokens_gdp[37];
                       output[1]=tokens_population[37];
                       output[2]= tokens_cpi[37];
                       output[3]=tokens_wpi[37];
                       output[4]=tokens_import[37];
                       output[5]=tokens_m3[37];
                       output[6]= tokens_unemp[37];
                       output[7]=tokens_inflation[37];
                       output[8] = tokens_indus[37];
                       output[9] = tokens_exchange[37]; 
                   }else if(quarter.equals("Q3"))
                   {
                       output[0]=tokens_gdp[38];
                       output[1]=tokens_population[38];
                       output[2]= tokens_cpi[38];
                       output[3]=tokens_wpi[38];
                       output[4]=tokens_import[38];
                       output[5]=tokens_m3[38];
                       output[6]= tokens_unemp[38];
                       output[7]=tokens_inflation[38];
                       output[8] = tokens_indus[38];
                       output[9] = tokens_exchange[38];
                   }else
                   {
                       output[0]=tokens_gdp[39];
                       output[1]=tokens_population[39];
                       output[2]= tokens_cpi[39];
                       output[3]=tokens_wpi[39];
                       output[4]=tokens_import[39];
                       output[5]=tokens_m3[39];
                       output[6]= tokens_unemp[39];
                       output[7]=tokens_inflation[39];
                       output[8] = tokens_indus[39];
                       output[9] = tokens_exchange[39];
                   }
                   break;
                }
            }
            JSONArray allValues = new JSONArray();
            JSONArray value = new JSONArray();
            JSONObject obj = new JSONObject();
            JSONObject inputs = new JSONObject();
            JSONObject input = new JSONObject();
            JSONArray columnName = new JSONArray();
            columnName.add("GDP");
            columnName.add("Population");
            columnName.add("CPI");
            columnName.add("WPI");
            columnName.add("Import");
            columnName.add("M3");
            columnName.add("Unemployment");
            columnName.add("Inflation_Rate");
            columnName.add("Industrial_Production");
            columnName.add("Exchange_Rate");
            columnName.add("Recession");
            value.add(Double.parseDouble(output[0]));
            value.add(Double.parseDouble(output[1]));
            value.add(Double.parseDouble(output[2]));
            value.add(Double.parseDouble(output[3]));
            value.add(Double.parseDouble(output[4]));
            value.add(Double.parseDouble(output[5]));
            value.add(Double.parseDouble(output[6]));
            value.add(Double.parseDouble(output[7]));
            value.add(Double.parseDouble(output[8]));
            value.add(Double.parseDouble(output[9]));
            value.add("");
            allValues.add(value);
            input.put("ColumnNames", columnName);
            input.put("Values", allValues);
            inputs.put("input1", input);
            obj.put("Inputs", inputs);
            jsonBodyrecessionin=obj.toJSONString();
            for(int k =0;k<output.length;k++)
            {
             desc[k] = output[k];
            }
            mv.addObject("output1", desc[0]);
            mv.addObject("output2",desc[1]);
            mv.addObject("output3",desc[2]);
            mv.addObject("output4",desc[3]);
            mv.addObject("output5",desc[4]);
            mv.addObject("output6",desc[5]);
            mv.addObject("output7",desc[6]);
            mv.addObject("output8",desc[7]);
            mv.addObject("output9",desc[8]);
            mv.addObject("output10",desc[9]);
            recession_in=am.callRandomForestIn(jsonBodyrecessionin);
            String delims = "[,]";
            String[] tokens_recession = recession_in.split(delims);

            tokens_recession[11] = tokens_recession[11].replace("\"", ""); 
            output[10]=tokens_recession[11];
            desc[10]=output[10];
            mv.addObject("output11",desc[10]);
        } else {
            System.out.println("Error thrown by web service call!!");
            mv.addObject("error", "invalid");
            return mv;
        }
    return  mv;
    }
    @RequestMapping(value = "/service", method = RequestMethod.POST)
    public ModelAndView service(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("index");
        String quarter = request.getParameter("quarter");
        int year = Integer.parseInt(request.getParameter("year"));
        String country = "USA";
        String jsonBody = null;
        String jsonBodyPop = null;
        String jsonBodyImp=null;
        String jsonBodyExp=null;
        String jsonBodyInf = null;
        String jsonBodyppi = null;
        String jsonBodyindus = null;
        String jsonBodyinc =null;
        String jsonBodycpi = null;
        String jsonBodyunemp=null;
        String jsonBodym2 = null;
        String jsonBodyrecessionus=null;
        int gdp =0;
        if (country.equals("india") || country.equals("USA") ) { 
            for(int i=0;i<11;i++)
            {
            JSONArray allValues = new JSONArray();
            JSONArray value = new JSONArray();
            JSONObject obj = new JSONObject();
            JSONObject inputs = new JSONObject();
            JSONObject input = new JSONObject();
            JSONArray columnName = new JSONArray();    
            columnName.add("quarter");
            columnName.add("Year");
            if(i==0)
            {
            columnName.add("GDP");
            }else if(i==1)
            {
            columnName.add("Population");
            }  else if(i==2){
                columnName.add("Import");
            }  
            else if(i==3){
                columnName.add("Export");
            }else if(i==4){
                columnName.add("Inflation.Rate");}
            else if(i==5){
                columnName.add("PPI");
            }else if(i==6){
                columnName.add("Industrial.Production");}
            else if(i==7){
                columnName.add("Real.Personal.Income");}
            else if(i==8){
                columnName.add("CPI");  }
            else if(i==9){columnName.add("Unemployment.Rate");}
            else if(i==10){columnName.add("M2");}
            value.add(quarter);
            value.add(year);
            value.add(0);
            allValues.add(value);
            input.put("ColumnNames", columnName);
            input.put("Values", allValues);
            inputs.put("input1", input);
            obj.put("Inputs", inputs);
            if(i ==0)
            {jsonBody = obj.toString();}
            else if(i == 1)
            {
            jsonBodyPop = obj.toString();
            }
            else if(i==2){jsonBodyImp=obj.toString();}
            else if(i==3){jsonBodyExp=obj.toString();}
            else if(i==4){jsonBodyInf=obj.toJSONString();}
            else if(i==5){jsonBodyppi=obj.toJSONString();}
            else if(i==6){jsonBodyindus=obj.toJSONString();}
            else if(i==7){jsonBodyinc=obj.toJSONString();}
            else if(i==8){jsonBodycpi=obj.toJSONString();}
            else if(i==9){jsonBodyunemp=obj.toJSONString();}
            else if(i==10){jsonBodym2=obj.toJSONString();}
            }
        }
       
        AzureML am = new AzureML();

        String gdp_us[] = new String[40];
        String population_us[] = new String[40];
        String import_us[]=new String[40];
        String export_us[]=new String[40];
        String inflation_us[]=new String[40];
        String ppi_us[]=new String[40];
        String indus_us[] = new String[40];
        String income_us[] = new String[40];
        String cpi_us[] = new String[40];
        String unemp_us[] = new String[40];
        String m2_us[] = new String[40];
        String recession_us=null;
       
           
             gdp_us = am.callTimeSeriesGdpUs(jsonBody);
             population_us = am.callTimeSeriesPopulationUs(jsonBodyPop);
             import_us=am.callTimeSeriesImportUs(jsonBodyImp);
             export_us=am.callTimeSeriesExportUs(jsonBodyExp);
             inflation_us=am.callTimeSeriesInflationUs(jsonBodyInf);
             ppi_us=am.callTimeSeriesPPIUs(jsonBodyppi);
             indus_us=am.callTimeSeriesIndustrialUs(jsonBodyindus);
             income_us=am.callTimeSeriesPersonalIncomeUs(jsonBodyinc);
             cpi_us=am.callTimeSeriesCpiUs(jsonBodycpi);
             unemp_us=am.callTimeSeriesUnemploymentRate(jsonBodyunemp);
             m2_us=am.callTimeSeriesM2Us(jsonBodym2);
       
        if (gdp_us != null && population_us!=null && import_us!=null && export_us!=null) {
            String[] tokens_gdp = new String[40];
            String[] tokens_population = new String[40];
            String[] tokens_import=new String[40];
            String[] tokens_export=new String[40];
            String[] tokens_inflation=new String[40];
            String[] tokens_ppi=new String[40];
            String[] tokens_industrial=new String[40];
            String[] tokens_income=new String[40];
            String[] tokens_cpi=new String[40];
            String[] tokens_unemp=new String[40];
            String[] tokens_m2=new String[40];
            
           for(int i =0 ;i<40;i++)
            {   
             String x = gdp_us[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_gdp[i] = x.replace("\"", "");
             x = population_us[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_population[i] = String.valueOf(ceil(Double.parseDouble(x.replace("\"", ""))));
             x = import_us[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_import[i] = x.replace("\"", "");
             x = export_us[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_export[i] = x.replace("\"", "");
             x = inflation_us[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_inflation[i] = x.replace("\"", "");
             x = ppi_us[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_ppi[i] = x.replace("\"", "");
             x = indus_us[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_industrial[i] = x.replace("\"", "");
             x = income_us[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_income[i] = x.replace("\"", "");
             x = cpi_us[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_cpi[i] = x.replace("\"", "");
             x = unemp_us[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_unemp[i] = x.replace("\"", "");
             x = m2_us[i].replaceAll("\\[", "").replaceAll("\\]","");
             tokens_m2[i] = x.replace("\"", ""); 
            }
            String[] desc = new String[20];
            String[] output = new String[20];
            switch(year)
            {
                case 2016:
                {
                   if(quarter.equals("Q1"))
                   {
                       output[0]=tokens_gdp[0];
                       output[1]=tokens_population[0];
                       output[2]=tokens_import[0];
                       output[3]=tokens_export[0];
                       output[4]=tokens_inflation[0];
                       output[5]=tokens_ppi[0];
                       output[6]=tokens_industrial[0];
                       output[7]=tokens_income[0];
                       output[8]=tokens_cpi[0];
                       output[9]=tokens_unemp[0];
                       output[10]=tokens_m2[0];
                   }else if(quarter.equals("Q2"))
                   {
                       output[0]=tokens_gdp[1];
                       output[1]=tokens_population[1];
                       output[2]=tokens_import[1];
                       output[3]=tokens_export[1];
                       output[4]=tokens_inflation[1];
                       output[5]=tokens_ppi[1];
                       output[6]=tokens_industrial[1];
                       output[7]=tokens_income[1];
                       output[8]=tokens_cpi[1];
                       output[9]=tokens_unemp[1];
                       output[10]=tokens_m2[1];
                   }else if(quarter.equals("Q3"))
                   {
                       output[0]=tokens_gdp[2];
                       output[1]=tokens_population[2];
                       output[2]=tokens_import[2];
                       output[3]=tokens_export[2];
                       output[4]=tokens_inflation[2];
                       output[5]=tokens_ppi[2];
                       output[6]=tokens_industrial[2];
                       output[7]=tokens_income[2];
                       output[8]=tokens_cpi[2];
                       output[9]=tokens_unemp[2];
                        output[10]=tokens_m2[2];
                   }else
                   {
                       output[0]=tokens_gdp[3];
                       output[1]=tokens_population[3];
                       output[2]=tokens_import[3];
                       output[3]=tokens_export[3];
                       output[4]=tokens_inflation[3];
                       output[5]=tokens_ppi[3];
                       output[6]=tokens_industrial[3];
                       output[7]=tokens_income[3];
                       output[8]=tokens_cpi[3];
                       output[9]=tokens_unemp[3];
                        output[10]=tokens_m2[3];
                   }
                   break;
                }
                case 2017:
                     {
                   if(quarter.equals("Q1"))
                   {
                       output[0]=tokens_gdp[4];
                       output[1]=tokens_population[4];
                       output[2]=tokens_import[4];
                       output[3]=tokens_export[4];
                       output[4]=tokens_inflation[4];
                       output[5]=tokens_ppi[4];
                       output[6]=tokens_industrial[4];
                       output[7]=tokens_income[4];
                       output[8]=tokens_cpi[4];
                       output[9]=tokens_unemp[4];
                        output[10]=tokens_m2[4];
                   }else if(quarter.equals("Q2"))
                   {
                       output[0]=tokens_gdp[5];
                       output[1]=tokens_population[5];
                       output[2]=tokens_import[5];
                       output[3]=tokens_export[5];
                       output[4]=tokens_inflation[5];
                       output[5]=tokens_ppi[5];
                       output[6]=tokens_industrial[5];
                       output[7]=tokens_income[5];
                       output[8]=tokens_cpi[5];
                       output[9]=tokens_unemp[5]; 
                       output[10]=tokens_m2[5]; 
                   }else if(quarter.equals("Q3"))
                   {
                       output[0]=tokens_gdp[6];
                       output[1]=tokens_population[6];
                       output[2]=tokens_import[6];
                       output[3]=tokens_export[6];
                       output[4]=tokens_inflation[6];
                       output[5]=tokens_ppi[6];
                       output[6]=tokens_industrial[6];
                       output[7]=tokens_income[6];
                       output[8]=tokens_cpi[6];
                       output[9]=tokens_unemp[6];
                       output[10]=tokens_m2[6]; 
                   }else
                   {
                       output[0]=tokens_gdp[7];
                       output[1]=tokens_population[7];
                       output[2]=tokens_import[7];
                       output[3]=tokens_export[7];
                       output[4]=tokens_inflation[7];
                       output[5]=tokens_ppi[7];
                       output[6]=tokens_industrial[7];
                       output[7]=tokens_income[7]; 
                       output[8]=tokens_cpi[7];
                       output[9]=tokens_unemp[7]; 
                       output[10]=tokens_m2[7]; 
                   }
                   break;
                }
                case 2018:
                {
                 if(quarter.equals("Q1"))
                   {
                      output[0]=tokens_gdp[8];
                      output[1]=tokens_population[8];
                      output[2]=tokens_import[8];
                      output[3]=tokens_export[8];
                      output[4]=tokens_inflation[8];
                      output[5]=tokens_ppi[8];
                      output[6]=tokens_industrial[8];
                      output[7]=tokens_income[8];
                      output[8]=tokens_cpi[8];
                      output[9]=tokens_unemp[8]; 
                      output[10]=tokens_m2[8]; 
                   }else if(quarter.equals("Q2"))
                   {
                       output[0]=tokens_gdp[9];
                       output[1]=tokens_population[9];
                       output[2]=tokens_import[9];
                       output[3]=tokens_export[9];
                       output[4]=tokens_inflation[9];
                       output[5]=tokens_ppi[9];
                       output[6]=tokens_industrial[9];
                       output[7]=tokens_income[9];
                       output[8]=tokens_cpi[9];
                       output[9]=tokens_unemp[9];
                       output[10]=tokens_m2[9]; 
                   }else if(quarter.equals("Q3"))
                   {
                       output[0]=tokens_gdp[10];
                       output[1]=tokens_population[10];
                       output[2]=tokens_import[10];
                       output[3]=tokens_export[10];
                       output[4]=tokens_inflation[10];
                       output[5]=tokens_ppi[10];
                       output[6]=tokens_industrial[10];
                       output[7]=tokens_income[10];
                       output[8]=tokens_cpi[10];
                       output[9]=tokens_unemp[10]; 
                       output[10]=tokens_m2[10]; 
                       
                   }else
                   {
                       output[0]=tokens_gdp[11];
                       output[1]=tokens_population[11];
                       output[2]=tokens_import[11];
                       output[3]=tokens_export[11];
                       output[4]=tokens_inflation[11];
                       output[5]=tokens_ppi[11];
                       output[6]=tokens_industrial[11];
                       output[7]=tokens_income[11];  
                       output[8]=tokens_cpi[11];
                       output[9]=tokens_unemp[11]; 
                       output[10]=tokens_m2[11]; 
                   }
                   break;
                }
                case 2019:
                {
                 if(quarter.equals("Q1"))
                   {
                       output[0]=tokens_gdp[12];
                       output[1]=tokens_population[12];
                       output[2]=tokens_import[12];
                       output[3]=tokens_export[12];
                       output[4]=tokens_inflation[12];
                       output[5]=tokens_ppi[12];
                       output[6]=tokens_industrial[12];
                       output[7]=tokens_income[12]; 
                       output[8]=tokens_cpi[12];
                       output[9]=tokens_unemp[12]; 
                       output[10]=tokens_m2[12]; 
                   }else if(quarter.equals("Q2"))
                   {
                       output[0]=tokens_gdp[13];
                       output[1]=tokens_population[13];
                       output[2]=tokens_import[13];
                       output[3]=tokens_export[13];
                       output[4]=tokens_inflation[13];
                       output[5]=tokens_ppi[13];
                       output[6]=tokens_industrial[13];
                       output[7]=tokens_income[13]; 
                       output[8]=tokens_cpi[13];
                       output[9]=tokens_unemp[13]; 
                       output[10]=tokens_m2[13]; 
                   }else if(quarter.equals("Q3"))
                   {
                       output[0]=tokens_gdp[14];
                       output[1]=tokens_population[14];
                       output[2]=tokens_import[14];
                       output[3]=tokens_export[14];
                       output[4]=tokens_inflation[14];
                       output[5]=tokens_ppi[14];
                       output[6]=tokens_industrial[14];
                       output[7]=tokens_income[14];
                       output[8]=tokens_cpi[14];
                       output[9]=tokens_unemp[14]; 
                       output[10]=tokens_m2[14]; 
                   }else
                   {
                       output[0]=tokens_gdp[15];
                       output[1]=tokens_population[15];
                       output[2]=tokens_import[15];
                       output[3]=tokens_export[15];
                       output[4]=tokens_inflation[15];
                       output[5]=tokens_ppi[15];
                       output[6]=tokens_industrial[15];
                       output[7]=tokens_income[15];
                       output[8]=tokens_cpi[15];
                       output[9]=tokens_unemp[15]; 
                       output[10]=tokens_m2[15]; 
                   }
                   break;
                }
                case 2020:
                {
                 if(quarter.equals("Q1"))
                   {
                       output[0]=tokens_gdp[16];
                       output[1]=tokens_population[16];
                       output[2]=tokens_import[16];
                       output[3]=tokens_export[16];
                       output[4]=tokens_inflation[16];
                       output[5]=tokens_ppi[16];
                       output[6]=tokens_industrial[16]; 
                       output[7]=tokens_income[16];
                       output[8]=tokens_cpi[16];
                       output[9]=tokens_unemp[16]; 
                       output[10]=tokens_m2[16]; 
                   }else if(quarter.equals("Q2"))
                   {
                       output[0]=tokens_gdp[17];
                       output[1]=tokens_population[17];
                       output[2]=tokens_import[17];
                       output[3]=tokens_export[17];
                       output[4]=tokens_inflation[17];
                       output[5]=tokens_ppi[17];
                       output[6]=tokens_industrial[17]; 
                       output[7]=tokens_income[17];
                       output[8]=tokens_cpi[17];
                       output[9]=tokens_unemp[17]; 
                       output[10]=tokens_m2[17]; 
                   }else if(quarter.equals("Q3"))
                   {
                      output[0]=tokens_gdp[18];
                       output[1]=tokens_population[18];
                       output[2]=tokens_import[18];
                       output[3]=tokens_export[18];
                       output[4]=tokens_inflation[18];
                       output[5]=tokens_ppi[18]; 
                       output[6]=tokens_industrial[18]; 
                       output[7]=tokens_income[18]; 
                       output[8]=tokens_cpi[18];
                       output[9]=tokens_unemp[18];
                       output[10]=tokens_m2[18];
                   }else
                   {
                      output[0]=tokens_gdp[19];
                       output[1]=tokens_population[19];
                       output[2]=tokens_import[19];
                       output[3]=tokens_export[19];
                       output[4]=tokens_inflation[19];
                       output[5]=tokens_ppi[19];
                       output[6]=tokens_industrial[19]; 
                       output[7]=tokens_income[19]; 
                       output[8]=tokens_cpi[19];
                       output[9]=tokens_unemp[19]; 
                       output[10]=tokens_m2[19]; 
                   }
                   break;
                }
                 case 2021:
                {
                 if(quarter.equals("Q1"))
                   {
                       output[0]=tokens_gdp[20];
                       output[1]=tokens_population[20];
                       output[2]=tokens_import[20];
                       output[3]=tokens_export[20];
                       output[4]=tokens_inflation[20];
                       output[5]=tokens_ppi[20]; 
                       output[6]=tokens_industrial[20];
                       output[7]=tokens_income[20];
                       output[8]=tokens_cpi[20];
                       output[9]=tokens_unemp[20];
                       output[10]=tokens_m2[20]; 
                   }else if(quarter.equals("Q2"))
                   {
                      output[0]=tokens_gdp[21];
                       output[1]=tokens_population[21];
                       output[2]=tokens_import[21];
                       output[3]=tokens_export[21];
                       output[4]=tokens_inflation[21];
                       output[5]=tokens_ppi[21]; 
                       output[6]=tokens_industrial[21]; 
                       output[7]=tokens_income[21]; 
                       output[8]=tokens_cpi[21];
                       output[9]=tokens_unemp[21];
                       output[10]=tokens_m2[21]; 
                   }else if(quarter.equals("Q3"))
                   {
                     output[0]=tokens_gdp[22];
                     output[1]=tokens_population[22];
                     output[2]=tokens_import[22];
                     output[3]=tokens_export[22];
                     output[4]=tokens_inflation[22];
                     output[5]=tokens_ppi[22];
                     output[6]=tokens_industrial[22]; 
                     output[7]=tokens_income[22]; 
                     output[8]=tokens_cpi[22];
                     output[9]=tokens_unemp[22]; 
                     output[10]=tokens_m2[22]; 
                   }else
                   {
                      output[0]=tokens_gdp[23];
                      output[1]=tokens_population[23];
                      output[2]=tokens_import[23];
                      output[3]=tokens_export[23];
                      output[4]=tokens_inflation[23];
                      output[5]=tokens_ppi[23]; 
                      output[6]=tokens_industrial[23];  
                      output[7]=tokens_income[23];
                      output[8]=tokens_cpi[23];
                      output[9]=tokens_unemp[23]; 
                      output[10]=tokens_m2[23]; 
                   }
                   break;
                }
                  case 2022:
                {
                 if(quarter.equals("Q1"))
                   {
                      output[0]=tokens_gdp[24];
                      output[1]=tokens_population[24];
                      output[2]=tokens_import[24];
                      output[3]=tokens_export[24];
                      output[4]=tokens_inflation[24];
                      output[5]=tokens_ppi[24];
                       output[6]=tokens_industrial[24]; 
                       output[7]=tokens_income[24];
                      output[8]=tokens_cpi[24]; 
                      output[9]=tokens_unemp[24]; 
                      output[10]=tokens_m2[24]; 
                   }else if(quarter.equals("Q2"))
                   {
                       output[0]=tokens_gdp[25];
                       output[1]=tokens_population[25];
                       output[2]=tokens_import[25];
                       output[3]=tokens_export[25];
                       output[4]=tokens_inflation[25];
                       output[5]=tokens_ppi[25];
                       output[6]=tokens_industrial[25];  
                       output[7]=tokens_income[25]; 
                       output[8]=tokens_cpi[25];
                       output[9]=tokens_unemp[25];
                       output[10]=tokens_m2[25]; 
                   }else if(quarter.equals("Q3"))
                   {
                       output[0]=tokens_gdp[26];
                       output[1]=tokens_population[26];
                       output[2]=tokens_import[26];
                       output[3]=tokens_export[26];
                       output[4]=tokens_inflation[26];
                       output[5]=tokens_ppi[26];
                       output[6]=tokens_industrial[26];  
                       output[7]=tokens_income[26]; 
                       output[8]=tokens_cpi[26];
                       output[9]=tokens_unemp[26]; 
                       output[10]=tokens_m2[26]; 
                   }else
                   {
                       output[0]=tokens_gdp[27];
                       output[1]=tokens_population[27];
                       output[2]=tokens_import[27];
                       output[3]=tokens_export[27];
                       output[4]=tokens_inflation[27];
                       output[5]=tokens_ppi[27]; 
                       output[6]=tokens_industrial[27];  
                       output[7]=tokens_income[27];
                       output[8]=tokens_cpi[27];
                       output[9]=tokens_unemp[27]; 
                       output[10]=tokens_m2[27]; 
                   }
                   break;
                }
                 case 2023:
                {
                 if(quarter.equals("Q1"))
                   {
                       output[0]=tokens_gdp[28];
                       output[1]=tokens_population[28];
                       output[2]=tokens_import[28];
                       output[3]=tokens_export[28];
                       output[4]=tokens_inflation[28];
                       output[5]=tokens_ppi[28];
                       output[6]=tokens_industrial[28]; 
                       output[7]=tokens_income[28];
                       output[8]=tokens_cpi[28];
                       output[9]=tokens_unemp[28]; 
                        output[10]=tokens_m2[28];
                   }else if(quarter.equals("Q2"))
                   {
                       output[0]=tokens_gdp[29];
                       output[1]=tokens_population[29];
                       output[2]=tokens_import[29];
                       output[3]=tokens_export[29];
                       output[4]=tokens_inflation[29];
                       output[5]=tokens_ppi[29]; 
                        output[6]=tokens_industrial[29]; 
                       output[7]=tokens_income[29]; 
                       output[8]=tokens_cpi[29];
                       output[9]=tokens_unemp[29]; 
                       output[10]=tokens_m2[29]; 
                   }else if(quarter.equals("Q3"))
                   {
                      output[0]=tokens_gdp[30];
                      output[1]=tokens_population[30];
                      output[2]=tokens_import[30];
                      output[3]=tokens_export[30];
                      output[4]=tokens_inflation[30];
                      output[5]=tokens_ppi[30]; 
                      output[6]=tokens_industrial[30];  
                     output[7]=tokens_income[30]; 
                     output[8]=tokens_cpi[30];
                     output[9]=tokens_unemp[30];
                      output[10]=tokens_m2[30];
                   }else
                   {
                       output[0]=tokens_gdp[31];
                       output[1]=tokens_population[31];
                       output[2]=tokens_import[31];
                       output[3]=tokens_export[31];
                       output[4]=tokens_inflation[31];
                       output[5]=tokens_ppi[31]; 
                       output[6]=tokens_industrial[31];  
                       output[7]=tokens_income[31]; 
                       output[8]=tokens_cpi[31];
                       output[9]=tokens_unemp[31];
                       output[10]=tokens_m2[31]; 
                   }
                   break;
                }
                  case 2024:
                {
                 if(quarter.equals("Q1"))
                   {
                       output[0]=tokens_gdp[32];
                       output[1]=tokens_population[32];
                       output[2]=tokens_import[32];
                       output[3]=tokens_export[32];
                       output[4]=tokens_inflation[32];
                       output[5]=tokens_ppi[32]; 
                       output[6]=tokens_industrial[32]; 
                       output[7]=tokens_income[32];
                       output[8]=tokens_cpi[32];
                       output[9]=tokens_unemp[32]; 
                       output[10]=tokens_m2[32]; 
                        
                   }else if(quarter.equals("Q2"))
                   {
                      output[0]=tokens_gdp[33];
                      output[1]=tokens_population[33];
                      output[2]=tokens_import[33];
                      output[3]=tokens_export[33];
                      output[4]=tokens_inflation[33];
                      output[5]=tokens_ppi[33]; 
                      output[6]=tokens_industrial[33]; 
                      output[8]=tokens_cpi[33];
                      output[9]=tokens_unemp[33];
                       output[10]=tokens_m2[33];
                   }else if(quarter.equals("Q3"))
                   {
                      output[0]=tokens_gdp[34];
                      output[1]=tokens_population[34];
                      output[2]=tokens_import[34];
                      output[3]=tokens_export[34];
                      output[4]=tokens_inflation[34];
                      output[5]=tokens_ppi[34];
                      output[6]=tokens_industrial[34];
                      output[7]=tokens_income[34];  
                      output[8]=tokens_cpi[34];
                      output[9]=tokens_unemp[34]; 
                      output[10]=tokens_m2[34]; 
                   }else
                   {
                       output[0]=tokens_gdp[35];
                       output[1]=tokens_population[35];
                       output[2]=tokens_import[35];
                       output[3]=tokens_export[35]; 
                       output[4]=tokens_inflation[35];
                       output[5]=tokens_ppi[35]; 
                       output[6]=tokens_industrial[35]; 
                       output[7]=tokens_income[35]; 
                       output[8]=tokens_cpi[35];
                       output[9]=tokens_unemp[35];
                       output[10]=tokens_m2[35]; 
                   }
                   break;
                }
                 case 2025:
                {
                 if(quarter.equals("Q1"))
                   {
                       output[0]=tokens_gdp[36];
                       output[1]=tokens_population[36];
                       output[2]=tokens_import[36];
                       output[3]=tokens_export[36]; 
                       output[4]=tokens_inflation[36];
                       output[5]=tokens_ppi[36]; 
                       output[6]=tokens_industrial[36]; 
                       output[7]=tokens_income[36];  
                       output[8]=tokens_cpi[36];
                       output[9]=tokens_unemp[36]; 
                        output[10]=tokens_m2[36];
                   }else if(quarter.equals("Q2"))
                       
                   {
                       output[0]=tokens_gdp[37];
                       output[1]=tokens_population[37];
                       output[2]=tokens_import[37];
                       output[3]=tokens_export[37];  
                       output[4]=tokens_inflation[37];
                       output[5]=tokens_ppi[37]; 
                       output[6]=tokens_industrial[37];  
                       output[7]=tokens_income[37];
                       output[8]=tokens_cpi[37];
                       output[9]=tokens_unemp[37]; 
                       output[10]=tokens_m2[37]; 
                   }else if(quarter.equals("Q3"))
                   {
                       output[0]=tokens_gdp[38];
                       output[1]=tokens_population[38];
                       output[2]=tokens_import[38]; 
                       output[3]=tokens_export[38]; 
                       output[4]=tokens_inflation[38];
                       output[5]=tokens_ppi[38];
                       output[6]=tokens_industrial[38];  
                       output[7]=tokens_income[38];
                       output[8]=tokens_cpi[38];
                       output[9]=tokens_unemp[38]; 
                        output[10]=tokens_m2[38];
                   }else
                   {
                       output[0]=tokens_gdp[39];
                       output[1]=tokens_population[39];
                       output[2]=tokens_import[39];
                       output[3]=tokens_export[39];  
                       output[4]=tokens_inflation[39];
                       output[5]=tokens_ppi[39]; 
                       output[6]=tokens_industrial[39];  
                       output[7]=tokens_income[39];
                       output[8]=tokens_cpi[39];
                       output[9]=tokens_unemp[39]; 
                       output[10]=tokens_m2[39];
                   }
                   break;
                }
            }
            JSONArray allValues = new JSONArray();
            JSONArray value = new JSONArray();
            JSONObject obj = new JSONObject();
            JSONObject inputs = new JSONObject();
            JSONObject input = new JSONObject();
            JSONArray columnName = new JSONArray();
            columnName.add("GDP");
            columnName.add("Population");
            columnName.add("CPI");
            columnName.add("PPI");
            columnName.add("Import");
            columnName.add("Export");
            columnName.add("M2");
            columnName.add("Unemployment.Rate");
            columnName.add("Industrial.Production");
            columnName.add("Real.Personal.Income");
            columnName.add("recession");
            value.add(Double.parseDouble(output[0]));
            value.add(ceil(Double.parseDouble(output[1])));
            value.add(Double.parseDouble(output[8]));
            value.add(Double.parseDouble(output[5]));
            value.add(Double.parseDouble(output[2]));
            value.add(Double.parseDouble(output[3]));
            value.add(Double.parseDouble(output[10]));
            value.add(Double.parseDouble(output[9]));
            value.add(Double.parseDouble(output[6]));
            value.add(Double.parseDouble(output[7]));
            value.add("");
            allValues.add(value);
            input.put("ColumnNames", columnName);
            input.put("Values", allValues);
            inputs.put("input1", input);
            obj.put("Inputs", inputs);
            jsonBodyrecessionus=obj.toJSONString();
            for(int k =0;k<output.length;k++)
            {
             desc[k] = output[k];
            }
            mv.addObject("output1", desc[0]);
            mv.addObject("output2",desc[1]);
            mv.addObject("output3",desc[2]);
            mv.addObject("output4",desc[3]);
            mv.addObject("output5",desc[4]);
            mv.addObject("output6",desc[5]);
            mv.addObject("output7",desc[6]);
            mv.addObject("output8",desc[7]);
            mv.addObject("output9",desc[8]);
            mv.addObject("output10",desc[9]);
            mv.addObject("output11",desc[10]);
            recession_us=am.callRandomForestUs(jsonBodyrecessionus);
            String delims = "[,]";
            String[] tokens_recession = recession_us.split(delims);

            tokens_recession[11] = tokens_recession[11].replace("\"", ""); 
            output[11]=tokens_recession[11];
            desc[11]=output[11];
            mv.addObject("output12",desc[11]);
        } else {
            System.out.println("Error thrown by web service call!!");
            mv.addObject("error", "invalid");
            return mv;
        }

        return mv;
    }
}